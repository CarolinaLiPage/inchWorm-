/**
 * @file main.cpp - driver code for the project
 * @author Carolina Li
 * @see "Seattle University, CPSC 5042, Spring 2024"
 *
 * This main.cpp  involving multiple animated objects, specifically "inchworms" and a cannon,
 * which are rendered on a pixel matrix. It initializes several instances of InchWorm and a Cannon,
 * managing their behavior and interactions through concurrent programming using threads, mutexes,
 * and barriers to synchronize the rendering and movement operations. Each inchworm and the cannon are
 * managed by separate threads facilitated through the ScreenManager class, which oversees the game
 * logic and ensures that all entities are updated in a coordinated manner.
 */

#include <iostream>
#include <future>
#include <barrier>
#include <atomic>
#include "Terminal.h"
#include "InchWorm.h"
#include "Cannon.h"

using namespace std;

/**
 * @class ScreenManager handles the game play, synchronizing with the other threads
 */
class ScreenManager {
public:
    ScreenManager(ScreenObject *screenObject, PixelMatrix *pxm, mutex *m, barrier<> *b) : screenObject(screenObject), pxm(pxm), lock(m), meetup(b) {}

    /**
     * This is the method running in the threads.
     * @return number of generations drawn
     */
    int play() {
        int generations = 0;
        while (!stop.test() && !screenObject->alive.test()) {
            generations++;

            // paint myself on the canvas (but avoid "mixed bodies" with the mutex)
            lock->lock();
            screenObject->render(*pxm);
            lock->unlock();

            // once we've all met up, all the rendering is done; wait for resumption point
            meetup->arrive_and_wait();

            // once the previous generation has been painted, move worm to next state
            meetup->arrive_and_wait();
            screenObject->move();
        }
        meetup->arrive_and_drop();
        return generations;
    }

public:
    atomic_flag stop;

private:
    ScreenObject *screenObject;
    PixelMatrix *pxm;
    mutex *lock;
    barrier<> *meetup;
};


/**
 * main thread
 */
int main() {
    const RGB BG_COLOR = RGB::BLACK;
    const int WAIT_TIME = 1;  // seconds to wait before starting
    const int THROTTLE = 250;  // milliseconds of pause between generations
    int aliveCount = 5;

    // create a  array holds 5 screen object pointers,
    // pass ing into cannon, check if cannon ball has colide with worm,
    // yes--> worm is dead, can kill multiple worms with 1 ball
    ScreenObject *screenObjs[5];

    cout << "Stop the wrigglers by typing any key." << endl;
    cout << "Try making them wiggle exactly 100 times!" << endl;
    this_thread::sleep_for(chrono::seconds(WAIT_TIME));

    // set up the terminal and the pixel matrix feeding it
    Terminal *t = new Terminal(false);  // false: makes hasKey work as expected
    int rows, cols;
    t->getSize(rows, cols);
    PixelMatrix pxm(rows, cols, BG_COLOR);

    // set up the synchronization
    barrier meetup(7);
    mutex lock;

    // set up the worms and their managers and get them all going
    InchWorm jake(5, 10, 1);
    ScreenManager jakeManager(&jake, &pxm, &lock, &meetup);
    future<int> jakeHandle = async(&ScreenManager::play, &jakeManager);
    InchWorm jill(9, 25, 2);
    ScreenManager jillManager(&jill, &pxm, &lock, &meetup);
    future<int> jillHandle = async(&ScreenManager::play, &jillManager);
    InchWorm ann(10, 5, 3);
    ScreenManager annManager(&ann, &pxm, &lock, &meetup);
    future<int> annHandle = async(&ScreenManager::play, &annManager);
    InchWorm alice(20,30, 2);
    ScreenManager aliceManager(&alice, &pxm, &lock, &meetup);
    future<int> aliceHandle = async(&ScreenManager::play, &aliceManager);
    InchWorm bob(30, 30, 4);
    ScreenManager bobManager(&bob, &pxm, &lock, &meetup);
    future<int> bobHandle = async(&ScreenManager::play, &bobManager);

    screenObjs[0] = &jake;
    screenObjs[1] = &jill;
    screenObjs[2] = &ann;
    screenObjs[3] = &alice;
    screenObjs[4] = &bob;

    Cannon cannon(screenObjs, 5);
    ScreenManager cannonManager(&cannon, &pxm, &lock, &meetup);
    future<int> cannonHandle = async(&ScreenManager::play, &cannonManager);

    // in the main thread wait for a key from the user
    while (aliveCount > 0) {
        this_thread::sleep_for(chrono::milliseconds(THROTTLE)); // pause for human to see
        meetup.arrive_and_wait();  // main thread waits for everyone to render
        t->paint(pxm); // paint the rendered pixel matrix
        pxm.paint(0, 0, rows, cols, BG_COLOR);  // fresh screen
        meetup.arrive_and_wait();  // now release everyone from their second wait
        try {
            t->getKey();
            cannon.fire();
        }
        catch(...) {
        }
        aliveCount = 0;
        for (int i = 0; i < 5; i++) {
            if (!screenObjs[i]->alive.test()) {
                aliveCount++;

            }
        }
    }
    // tell the wrigglers to stop
    jakeManager.stop.test_and_set();
    jillManager.stop.test_and_set();
    annManager.stop.test_and_set();
    aliceManager.stop.test_and_set();
    bobManager.stop.test_and_set();
    cannonManager.stop.test_and_set();

    // make sure nobody is stuck at the barrier
    meetup.arrive_and_wait(); // first stop
    meetup.arrive_and_wait(); // second stop

    // keep final screen up for a second
    this_thread::sleep_for(chrono::seconds(WAIT_TIME));

    // get the wrigglers' values
    int jakePlayed = jakeHandle.get();
    int jillPlayed = jillHandle.get();
    int annPlayed = annHandle.get();
    int alicePlayed = aliceHandle.get();
    int bobPlayed = bobHandle.get();


    delete t;  // destruction of the Terminal object returns the screen to normal shell mode

    cout << "Jake wriggled " << jakePlayed << " times!" << endl;
    cout << "Jill wiggled " << jillPlayed << " times!" << endl;
    cout << "Ann wiggled " << annPlayed << " times!" << endl;
    cout << "Alice wiggled " << alicePlayed << " times!" << endl;
    cout << "Bob wiggled " << bobPlayed << " times!" << endl;
    return EXIT_SUCCESS;
}
