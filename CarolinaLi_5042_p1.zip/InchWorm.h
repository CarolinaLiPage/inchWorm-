/**
 * @file InchWorm.h - A Wriggling Worm!
 * @author Carolina Li
 * @see "Seattle University, CPSC 5042, Spring 2024"
 *
 * The InchWorm file defines a class for creating and managing an "inchworm" object within a graphical
 application. This inchworm is represented as a series of pixels on a grid, and it moves across
 this grid based on a defined speed and changes its shape according to its internal state.
 Specifically, the constructor initializes the worm with its position and speed. The render method draws
 the inchworm on a pixel matrix, changing its color and shape depending on its state, which is influenced
 by the move method that cycles through different states to simulate movement.
 The isCollision method checks if a given point intersects with the inchworm's current position,
 useful for detecting interactions or collisions with other objects in the environment.
 */

#pragma once
#include "PixelMatrix.h"
#include "ScreenObject.h"

/**
 * @class Wriggler - Critter that wriggles around like an inch worm on the screen.
 *
 */

class InchWorm: public ScreenObject {
public:
    //const static int ROW = 10, COLUMN = 20;  // where the wriggler wriggles
    // Constructor: Initializes the InchWorm with location, speed, and initial state.
    InchWorm(int rowLoc, int colLoc, int speed) ;  // wriggler starts out in state A
    // Move method: Cycles through different states (A, B, C, D) to simulate the worm's movement.
    void move();
    // Render method: Draws the InchWorm on the PixelMatrix with dynamic shape and color changes based on its state.
    void InchWorm::render(PixelMatrix &pxm) {...}
    void render(PixelMatrix &pxm) ;
    // Collision detection: Checks if a specific row and column intersect with the InchWorm's current position.
    bool InchWorm::isCollision(int row, int col) {...}
    bool isCollision(int row, int col);
private:
    enum State {A, B, C, D};  // four oscillation position states
    State state;
    int rowLoc;
    int colLoc;
    int speed;
};

