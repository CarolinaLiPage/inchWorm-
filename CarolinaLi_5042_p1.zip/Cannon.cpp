/**
 * @file Cannon.cpp - A Wriggling Worm!
 * @author Carolina Li
 * @see "Seattle University, CPSC 5042, Spring 2024"
 *
 *  * The Cannon class represents a cannon in a graphical application, managing its display and
 * interaction within a 2D environment. The class handles rendering the cannon and its cannonball
 * on a pixel matrix, updating the cannonball's position, and handling its firing mechanism.
 * The cannon is represented by specific pixels in a grid, and the cannonball's movement considers
 * collision detection with other objects within the scene.
 */

#include "Cannon.h"

// constructor for inchWorm
Cannon::Cannon(ScreenObject **screenObjs, int size) {
    this->screenObjs = screenObjs;
    this->size = size;
    ballRow = ROW;
}

void Cannon::render(PixelMatrix &pxm) {
    const int N = 8;
    const int R = ROW; // row number
    const int C = COLUMN;
    const RGB WHITE(0xff, 0xff, 0xff);
    int row[N], col[N];

    // Set the rows and columns for the cannon pixels
    row[0] = row[1] = row[2] = R;
    row[3] = row[4] = row[5] = R - 1;
    row[6] = R - 2;
    row[7] = R - 3;
    col[0] = col[3] = C - 1;
    col[1] = col[4] = col[6] = col[7] = C;
    col[2] = col[5] = C + 1;

    // Paint the cannon pixels on the matrix
    for (int i = 0; i < N; i++) {
        pxm.paint(row[i], col[i], WHITE);
    }
    //ballRow -= 2;
    pxm.paint(ballRow, ballCol, WHITE);
}

// move cannon ball
void Cannon::move() {
    if (ballRow != ROW && ballRow > -1) {
        ballRow -= 2;
        for (int i = 0; i < size; i++) {
            if (screenObjs[i]->isCollision(ballRow, ballCol)) {
                screenObjs[i]->alive.test_and_set();
            }
        }
    }
}

// fire the cannon
void Cannon::fire() {
    if (ballRow == ROW || ballRow < 0) {
        ballRow = ROW - 4;
    }
}
