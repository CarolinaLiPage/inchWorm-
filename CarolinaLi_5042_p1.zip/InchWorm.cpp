/**
 * @file InchWorm.cpp - A Wriggling Worm!
 * @author Carolina Li
 * @see "Seattle University, CPSC 5042, Spring 2024"
 *
 * The InchWorm file defines a class for creating and managing an "inchworm" object within a graphical
 application. This inchworm is represented as a series of pixels on a grid, and it moves across
 this grid based on a defined speed and changes its shape according to its internal state.
 Specifically, the constructor initializes the worm with its position and speed. The render method draws
 the inchworm on a pixel matrix, changing its color and shape depending on its state, which is influenced
 by the move method that cycles through different states to simulate movement.
 The isCollision method checks if a given point intersects with the inchworm's current position,
 useful for detecting interactions or collisions with other objects in the environment.
 */

#include "InchWorm.h"

// constructor for inchWorm
InchWorm::InchWorm(int rowLoc, int colLoc, int speed) : state(A){
    this->rowLoc = rowLoc;
    this->colLoc = colLoc;
    this->speed = speed;
}

void InchWorm::render(PixelMatrix &pxm) {
    const int N = 11;
    const RGB PINK(0xff, 0x00, 0xff);
    const RGB BLOOD(0x8a, 0x03, 0x03);
    int row[N], col[N];
    colLoc += speed;
    if (colLoc <= 3 || colLoc > 76) {
        speed *= -1;

    }
    int c = colLoc;
    switch(state) {
        case A:
        case C:
            for (int i = 0; i < N; i++) {
                row[i] = rowLoc;
                col[i] = c++;
            }
            break;
        case B:
            row[0] = row[1] = row[4] = rowLoc;
            row[5] = row[6] = row[9] = rowLoc;
            row[10] = rowLoc;
            row[2] = row[3] = rowLoc + 1;
            row[7] = row[8] = rowLoc + 1;
            col[0] = colLoc + 1;
            col[1] = col[2] = col[0] + 1;
            col[3] = col[4] = col[1] + 1;
            col[5] = col[3] + 1;
            col[6] = col[7] = col[5] + 1;
            col[8] = col[9] = col[6] + 1;
            col[10] = col[8] + 1;
            break;
        case D:
            row[0] = row[1] = row[4] = rowLoc;
            row[5] = row[6] = row[9] = rowLoc;
            row[10] = rowLoc;
            row[2] = row[3] = rowLoc - 1;
            row[7] = row[8] = rowLoc - 1;
            col[0] = colLoc + 3;
            col[1] = col[2] = col[0] + 1;
            col[3] = col[4] = col[1] + 1;
            col[5] = col[3] + 1;
            col[6] = col[7] = col[5] + 1;
            col[8] = col[9] = col[6] + 1;
            col[10] = col[8] + 1;
            break;
    }
    for (int i = 0; i < N; i++)
        pxm.paint(row[i], col[i], i % 2 == 0 ? BLOOD : PINK);
}

void InchWorm::move() {
    switch(state) {
        case A:
            state = B;
            break;
        case B:
            state = C;
            break;
        case C:
            state = D;
            break;
        case D:
            state = A;
            break;
    }
}

bool InchWorm::isCollision(int row, int col) {
    if ((rowLoc == row || rowLoc==row-1) && col >= colLoc && col <= colLoc+9) {
        return true;
    }
    return false;
}
