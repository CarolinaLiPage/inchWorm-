/**
 * @file ScreenObject.h - A cannon that can shoot the worm.
 * @author Carolina Li
 * @see "Seattle University, CPSC 5042, Spring 2024"
 *
 */

#pragma once
#include "PixelMatrix.h"
#include <barrier>
using namespace std;


/**
 * @class ScreenObject
 *
 * The ScreenObject class serves as an abstract base class designed to define the interface
 * and common behavior for objects that can be rendered on a screen in a graphical application.
 * It includes an atomic_flag named alive to manage the lifecycle status of objects,
 * ensuring thread-safe checks and updates to the object's state.
 * The class mandates the implementation of three key virtual methods:
 * move(), render(PixelMatrix &pxm), and isCollision(int row, int col),
 * which must be defined by any derived classes to handle their specific movement behaviors,
 * how they are drawn to a PixelMatrix, and collision detection with other objects on the screen,
 * respectively. This setup allows for polymorphic handling of different screen objects within the game
 * or application, facilitating operations like rendering and movement within a unified framework.
 *
 */
class ScreenObject {
public:
    atomic_flag alive;
    //Initializes a new ScreenObject, setting it up with an initial state.
    ScreenObject() {};  // wriggler starts out in state A
    // Pure virtual function, actual implementation depends on the derived class
    virtual void move() = 0;
    // Pure virtual function, actual implementation depends on the derived class
    virtual void render(PixelMatrix &pxm) = 0;
    // Provides a basic implementation for collision detection that
    // can be overridden in derived classes
    virtual bool isCollision(int row, int col) {return false;}
private:

};

