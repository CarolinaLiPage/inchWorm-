/**
 * @file Cannon.h - A cannon that can shoot the worm.
 * @author Carolina Li
 * @see "Seattle University, CPSC 5042, Spring 2024"
 */

#pragma once
#include "PixelMatrix.h"
#include "ScreenObject.h"

/**
 * @class Cannon - Critter that wriggles around like an inch worm on the screen.
 *
 * The Cannon class represents a cannon in a graphical application, managing its display and
 * interaction within a 2D environment. The class handles rendering the cannon and its cannonball
 * on a pixel matrix, updating the cannonball's position, and handling its firing mechanism.
 * The cannon is represented by specific pixels in a grid, and the cannonball's movement considers
 * collision detection with other objects within the scene.
 */
class Cannon : public ScreenObject{
public:
    const static int ROW = 40, COLUMN = 42;  // where the wriggler wriggles
    // Constructor: Initializes a Cannon object with an array of screen objects and its size
    Cannon(ScreenObject **screenObjs, int size) ;  // wriggler starts out in state A
    // Move method: Updates the position of the cannonball
    void move();
    // Render method: Displays the cannon and its cannonball on a pixel matrix
    void render(PixelMatrix &pxm) ;
    // Fire method: Initiates the movement of the cannonball from its starting position
    void fire();
private:
    ScreenObject **screenObjs;
    int size;
    int ballRow;
    int ballCol =  COLUMN;
};

